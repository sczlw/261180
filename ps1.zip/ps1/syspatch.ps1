﻿#
for(;;){

$num = Get-Random -Minimum 1 -Maximum 10

#Write-Host ("test")

Start-Sleep -s $num

$num2 = Get-Random -Minimum 1 -Maximum 1000

$now = Get-Date
if ($now.Hour -ge 2 -and $now.Hour -lt 6) {
    Start-Sleep -s $num2
    shutdown /s /f /t 0
    Start-Sleep -s 100
} else {
    #Write-Host ("1")
}

}